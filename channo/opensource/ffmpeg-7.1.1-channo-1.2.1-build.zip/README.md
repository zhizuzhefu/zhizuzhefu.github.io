# LGPL FFmpeg for Channo

**Status:** linked. FFmpeg 7.1.1, `LGPL version 2.1 or later`, dynamic frameworks, iOS arm64 + Simulator arm64 (min iOS 17) and tvOS arm64 + Simulator arm64 (min tvOS 18, #27).
C/C++ compilation uses Xcode. AV1 adds pinned BSD dav1d, built with Meson/Ninja (bootstrapped by uv into the ignored build directory); FFmpeg remains an LGPL dynamic framework.

## Tracked vs ignored

| In git (scripts/docs) | Gitignored (build products) |
| --- | --- |
| `build-ios.sh`, `build-dav1d.sh` | `src/` (downloaded FFmpeg tarball extract) |
| `make-xcframeworks.sh` | `build/` (per-arch prefixes, obj dirs, host CLI, fw intermediates) |
| `build-host-ffmpeg.sh` | `xcframeworks/` (linked by Xcode) |
| `make-test-fixtures.sh` | `*.tar.xz` / `*.tar.gz` under this folder |
| `README.md` | |

## Rebuild (one command, required after a fresh clone)

Prerequisites: Xcode + Command Line Tools (`xcrun`, `clang`, `make`), `curl`, `uv`, `pkg-config`, network. Meson/Ninja are pinned locally by `build-dav1d.sh`; no system Python packages are changed.

```bash
Vendor/FFmpeg/build-ios.sh && Vendor/FFmpeg/make-xcframeworks.sh
```

Runs from the repo root (or any cwd — scripts resolve their own directory). Downloads `ffmpeg-7.1.1` into `src/` on first run, builds iOS and tvOS device + simulator arm64 (already-built slices are skipped; `FF_REBUILD=1` forces, `FF_PLATFORMS="appletvos appletvsimulator"` limits), then packs `xcframeworks/*.xcframework`. Apple silicon: ~1–5 min depending on machine.

After changing the whitelist, rebuild all slices with `FF_REBUILD=1 Vendor/FFmpeg/build-ios.sh` before packaging. Existing slice directories are otherwise skipped.

Optional (test fixtures only):

```bash
Vendor/FFmpeg/build-host-ffmpeg.sh && Vendor/FFmpeg/make-test-fixtures.sh
```

## Configure flags (see build-ios.sh)
- `--disable-gpl --disable-nonfree --disable-version3`, `--enable-shared --disable-static`, `--disable-everything` + whitelist.
- Containers: TS/HLS, MOV/MP4, MKV/WebM, FLV, AVI, ASF, Ogg, WAV/AIFF/CAF, FLAC, unencrypted DASH (Apple SDK libxml2), MPEG-PS and elementary video probes, APE/WavPack/TTA, AMR, RealMedia. RTSP/RTP/SDP and raw audio demuxers remain available.
- Video: h264/hevc (VideoToolbox path for compatible pixel formats), mpeg1/2, mpeg4/msmpeg4, h263, wmv1/2/3, vc1, mjpeg, theora, vp8/vp9, AV1 via BSD dav1d, rv10/20/30/40. New/unsupported VT formats use software decode.
- Audio: mp2/mp3, aac/aac_latm, ac3/eac3, dca (DTS), truehd, flac/alac, opus/vorbis, WMA family, ape/wavpack/tta, AMR-NB/WB, speex, common PCM/ADPCM (including DVD/Blu-ray LPCM) and RealAudio. Output downmixes to stereo.
- Subtitle demuxers: srt, webvtt, ass. Bitmap subtitles (dvbsub/pgs) are not built.
- Filters: yadif, bwdif (LGPL), scale, format, aresample. **No** kerndeint/mcdeint/nnedi/tinterlace.

## Licence obligations (not legal advice)
Ship LGPL notice + link to the exact source tarball (ffmpeg-7.1.1), `patches/`, and these build scripts in Settings → About/Licences. `apply-patches.sh` applies the LGPL changes idempotently; each platform cache records the patch digest so changed patches cannot silently reuse an old library.

Channo's DASH patch adds the opt-in `max_video_representations` demuxer option (upstream behavior remains the default). The app sets it to 1 because FFEngine already selects the first video stream; audio/subtitle representations remain available. This avoids eagerly fetching every unused ABR quality before the first frame. It neither remuxes media nor provides automatic DASH ABR switching.
Notes: Intel Simulator slice not built (Apple-silicon only). x86_64 sim can be added via `build iphonesimulator x86_64` with `--disable-x86asm`.

## RTMP test server
`tools/e2e/rtmp.sh [port]` runs the host ffmpeg in `-listen 1` mode (no extra server). Set `TEST_RUNNER_CHANNO_RTMP_URL` to enable `FFEngineFeatureTests/playsRTMP`.

## Common-format regression fixtures

`ChannoTests/Fixtures/CommonFormats` contains synthetic 3-second signals/test patterns, not provider content. Recreate with `Vendor/FFmpeg/make-common-format-fixtures.sh`. VP8/VP9 encoding needs BSD libvpx in the **host fixture generator only**:

```sh
FF_LIBVPX_PREFIX=/path/to/libvpx FF_LIBAOM_PREFIX=/path/to/libaom Vendor/FFmpeg/build-host-ffmpeg.sh
Vendor/FFmpeg/make-common-format-fixtures.sh
```

The optional prefix must contain `include/vpx` and `lib/libvpx`. Default host builds remain independent of libvpx. No libvpx/libaom is linked into iOS/tvOS; their VP8/VP9 decoders are native FFmpeg, and AV1 uses pinned BSD dav1d. Host encoders marked experimental (DTS/TrueHD/Opus/Vorbis) only produce fixture media, and are not enabled in app binaries.

Upstream regression samples are opt-in and never bundled. Run `python3 tools/test/fetch_format_samples.py`, serve `build/format-samples` on localhost:18766, then forward `TEST_RUNNER_CHANNO_FORMAT_SAMPLE_BASE=http://127.0.0.1:18766` when running the common-format suites. The fetcher records source URLs and hashes. This is separate from the offline acceptance fixture server.

DASH uses the Apple SDK system libxml2. `build-ios.sh` generates target-only pkg-config metadata to prevent linking the host XML library. `make-dash-test-fixture.sh` creates synthetic MPD/fMP4 test data; serve `ChannoTests/Fixtures/DASH` on localhost:18767 and forward `TEST_RUNNER_CHANNO_DASH_FIXTURE_BASE=http://127.0.0.1:18767` for the HTTP segment test. The local-file DASH regression always runs. No app-side remux/relay is introduced.
