#!/bin/bash
# Wrap build/<plat>/lib/*.dylib into dynamic .framework bundles, then .xcframework (App Store–compatible).
# Run after build-ios.sh. Uses only Xcode tools (xcodebuild, install_name_tool, otool).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; B="$ROOT/build"; OUT="$ROOT/xcframeworks"
LIBS="avutil swresample swscale avcodec avformat avfilter"

PLATS="iphoneos-arm64 iphonesimulator-arm64 appletvos-arm64 appletvsimulator-arm64"
for plat in $PLATS; do
  [ -d "$B/$plat/lib" ] || {
    echo "error: missing $B/$plat/lib — run Vendor/FFmpeg/build-ios.sh first" >&2
    exit 1
  }
done

rm -rf "$OUT" "$B/fw" "$B/dSYMs"; mkdir -p "$OUT"
for plat in $PLATS; do
  case $plat in appletv*) MINOS=18.0 ;; *) MINOS=17.0 ;; esac
  for lib in $LIBS; do
    fw="$B/fw/$plat/lib$lib.framework"; mkdir -p "$fw/Headers"
    real=$(ls "$B/$plat/lib/lib$lib".*.*.*.dylib | head -1)
    cp "$real" "$fw/lib$lib"
    install_name_tool -id "@rpath/lib$lib.framework/lib$lib" "$fw/lib$lib"
    for dep in $LIBS; do
      old=$(otool -L "$fw/lib$lib" | awk '{print $1}' | grep "lib$dep\." || true)
      [ -n "$old" ] && install_name_tool -change "$old" "@rpath/lib$dep.framework/lib$dep" "$fw/lib$lib"
    done
    # Debug information lives in a separate dSYM; shipped frameworks remain stripped.
    mkdir -p "$B/dSYMs/$plat"
    xcrun dsymutil "$fw/lib$lib" -o "$B/dSYMs/$plat/lib$lib.framework.dSYM"
    xcrun strip -S -x "$fw/lib$lib"
    cp -R "$B/$plat/include/lib$lib/." "$fw/Headers/"
    cat > "$fw/Info.plist" <<PL
<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleExecutable</key><string>lib$lib</string>
<key>CFBundleIdentifier</key><string>org.ffmpeg.lib$lib</string>
<key>CFBundlePackageType</key><string>FMWK</string>
<key>CFBundleShortVersionString</key><string>7.1.1</string>
<key>CFBundleVersion</key><string>7.1.1</string>
<key>MinimumOSVersion</key><string>$MINOS</string>
</dict></plist>
PL
  done
done
for lib in $LIBS; do
  xcodebuild -create-xcframework \
    -framework "$B/fw/iphoneos-arm64/lib$lib.framework" \
    -debug-symbols "$B/dSYMs/iphoneos-arm64/lib$lib.framework.dSYM" \
    -framework "$B/fw/iphonesimulator-arm64/lib$lib.framework" \
    -debug-symbols "$B/dSYMs/iphonesimulator-arm64/lib$lib.framework.dSYM" \
    -framework "$B/fw/appletvos-arm64/lib$lib.framework" \
    -debug-symbols "$B/dSYMs/appletvos-arm64/lib$lib.framework.dSYM" \
    -framework "$B/fw/appletvsimulator-arm64/lib$lib.framework" \
    -debug-symbols "$B/dSYMs/appletvsimulator-arm64/lib$lib.framework.dSYM" \
    -output "$OUT/lib$lib.xcframework" >/dev/null
done
ls "$OUT"
echo "DONE: $OUT"
