#!/bin/bash
# BSD-2-Clause AV1 decoder, linked as PIC objects inside the LGPL shared libavcodec.
# No additional app framework. Pinned upstream release + SHA-256.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
VER=1.5.4
SHA=686616b7c69eb88d44459391ab25cac13b6647a3b288835c5784e71c1514a5c5
SRC="$ROOT/src/dav1d-$VER"
B="$ROOT/build"
TOOLS="$B/dav1d-tools"
mkdir -p "$ROOT/src" "$B"
if [ ! -x "$TOOLS/bin/meson" ] || [ ! -x "$TOOLS/bin/ninja" ]; then
  command -v uv >/dev/null || { echo "dav1d build needs uv to install pinned Meson/Ninja into Vendor/FFmpeg/build." >&2; exit 1; }
  uv venv "$TOOLS"
  uv pip install --python "$TOOLS/bin/python" meson==1.7.2 ninja==1.11.1.4
fi
export PATH="$TOOLS/bin:$PATH"
if [ ! -d "$SRC" ]; then
  ARCHIVE="$B/dav1d-$VER.tar.xz"
  curl -fsSL "https://downloads.videolan.org/pub/videolan/dav1d/$VER/dav1d-$VER.tar.xz" -o "$ARCHIVE"
  printf '%s  %s\n' "$SHA" "$ARCHIVE" | shasum -a 256 -c -
  tar -xJf "$ARCHIVE" -C "$ROOT/src"
fi
for SDK in ${FF_PLATFORMS:-iphoneos iphonesimulator appletvos appletvsimulator}; do
  case "$SDK" in
    iphoneos) MIN=-mios-version-min=17.0; SYSTEM=ios ;;
    iphonesimulator) MIN=-mios-simulator-version-min=17.0; SYSTEM=ios ;;
    appletvos) MIN=-mappletvos-version-min=18.0; SYSTEM=tvos ;;
    appletvsimulator) MIN=-mappletvsimulator-version-min=18.0; SYSTEM=tvos ;;
    *) echo "Unknown SDK $SDK" >&2; exit 1 ;;
  esac
  PREFIX="$B/dav1d-$SDK-arm64"; OBJ="$B/obj-dav1d-$SDK-arm64"
  CROSS="$B/dav1d-$SDK.cross"
  SYSROOT=$(xcrun --sdk "$SDK" --show-sdk-path)
  cat > "$CROSS" <<CROSSFILE
[binaries]
c = ['xcrun', '--sdk', '$SDK', 'clang']
ar = ['xcrun', '--sdk', '$SDK', 'ar']
strip = ['xcrun', '--sdk', '$SDK', 'strip']
[host_machine]
system = '$SYSTEM'
cpu_family = 'aarch64'
cpu = 'arm64'
endian = 'little'
[properties]
needs_exe_wrapper = true
[built-in options]
c_args = ['-arch', 'arm64', '-isysroot', '$SYSROOT', '$MIN', '-g']
c_link_args = ['-arch', 'arm64', '-isysroot', '$SYSROOT', '$MIN']
CROSSFILE
  SETUP=(meson setup "$OBJ" "$SRC")
  [ ! -f "$OBJ/build.ninja" ] || SETUP+=(--reconfigure)
  "${SETUP[@]}" --cross-file "$CROSS" \
    --prefix "$PREFIX" --libdir lib --buildtype release --default-library static \
    -Db_staticpic=true -Denable_tools=false -Denable_tests=false -Denable_examples=false
  meson compile -C "$OBJ" -j "$(sysctl -n hw.ncpu)"
  meson install -C "$OBJ"
done
