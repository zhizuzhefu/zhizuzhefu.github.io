#!/bin/bash
# Host (macOS) ffmpeg CLI used ONLY to generate test fixtures (ChannoTests/Fixtures).
# Same LGPL 2.1 source as build-ios.sh, Xcode toolchain only. Output: build/host (gitignored).
# Prerequisites: Xcode CLT. If src/ is missing, downloads the same tarball as build-ios.sh.
set -euo pipefail
VER=${FFMPEG_VERSION:-7.1.1}
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/src/ffmpeg-$VER"
OUT="$HERE/build/host"
OBJ="$HERE/build/obj-host"

command -v xcrun >/dev/null || { echo "error: xcrun not found — install Xcode Command Line Tools" >&2; exit 1; }

mkdir -p "$HERE/src" "$OBJ"
if [ ! -d "$SRC" ]; then
  echo "Downloading ffmpeg-$VER…"
  curl -fsSL "https://ffmpeg.org/releases/ffmpeg-$VER.tar.xz" | tar -xJ -C "$HERE/src"
fi
[ -x "$SRC/configure" ] || { echo "error: missing $SRC/configure" >&2; exit 1; }
bash "$HERE/apply-patches.sh" "$SRC"

# Optional BSD libvpx/libaom, used only to encode synthetic VP8/VP9/AV1 fixtures.
# The app uses FFmpeg's built-in decoders and never links this host dependency.
EXTRA=(--disable-libvpx --disable-libaom)
ENC_CFLAGS=""
ENC_LDFLAGS=""
if [ -n "${FF_LIBVPX_PREFIX:-}" ]; then
  EXTRA+=(--enable-libvpx)
  ENC_CFLAGS+=" -I$FF_LIBVPX_PREFIX/include"
  ENC_LDFLAGS+=" -L$FF_LIBVPX_PREFIX/lib"
fi
if [ -n "${FF_LIBAOM_PREFIX:-}" ]; then
  EXTRA+=(--enable-libaom)
  ENC_CFLAGS+=" -I$FF_LIBAOM_PREFIX/include"
  ENC_LDFLAGS+=" -L$FF_LIBAOM_PREFIX/lib"
fi
EXTRA+=("--extra-cflags=$ENC_CFLAGS" "--extra-ldflags=$ENC_LDFLAGS")
cd "$OBJ"
"$SRC/configure" --prefix="$OUT" --disable-gpl --disable-nonfree --disable-version3 \
  --disable-autodetect --enable-videotoolbox --enable-audiotoolbox --disable-doc --disable-ffplay --disable-ffprobe \
  --enable-static --disable-shared "${EXTRA[@]}"
make -j"$(sysctl -n hw.ncpu)" && make install
echo "DONE: $OUT/bin/ffmpeg"
