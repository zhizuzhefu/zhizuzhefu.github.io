#!/bin/bash
# LGPL 2.1 FFmpeg for Channo; Xcode + pinned Meson/Ninja for BSD dav1d.
# Prerequisites: Xcode CLT, curl, uv, pkg-config, network (see README).
set -euo pipefail
VER=${FFMPEG_VERSION:-7.1.1}
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/src/ffmpeg-$VER"
OUT="$ROOT/build"

command -v xcrun >/dev/null || { echo "error: xcrun not found — install Xcode Command Line Tools" >&2; exit 1; }
command -v curl >/dev/null || { echo "error: curl not found" >&2; exit 1; }

mkdir -p "$ROOT/src" "$OUT"
"$ROOT/build-dav1d.sh"
command -v pkg-config >/dev/null || { echo "error: pkg-config required for the pinned dav1d dependency" >&2; exit 1; }
if [ ! -d "$SRC" ]; then
  echo "Downloading ffmpeg-${VER}…"
  curl -fsSL "https://ffmpeg.org/releases/ffmpeg-$VER.tar.xz" | tar -xJ -C "$ROOT/src"
fi
[ -x "$SRC/configure" ] || { echo "error: missing $SRC/configure" >&2; exit 1; }
bash "$ROOT/apply-patches.sh" "$SRC"
BUILD_DIGEST=$({ cat "$0" "$ROOT/build-dav1d.sh"; cat "$ROOT"/patches/*.patch; } | shasum -a 256 | awk '{print $1}')

COMMON=(--disable-gpl --disable-nonfree --disable-version3
  --enable-shared --disable-static --disable-programs --disable-doc --enable-debug=2 --disable-stripping
  --disable-everything --disable-autodetect --enable-pic
  --enable-protocol=file,http,https,tcp,tls,hls,rtmp,udp,rtp,crypto
  --enable-securetransport --enable-libdav1d --enable-libxml2
  --enable-demuxer=mpegts,hls,flv,live_flv,mov,matroska,avi,ogg,wav,flac,asf,aiff,caf,dash,ape,tta,wv,amr,ac3,eac3,dts,truehd,ivf,mjpeg,rm,mpegps,mpegvideo,h264,hevc,m4v,aac,mp3,rtsp,rtp,sdp,srt,webvtt,ass
  --enable-parser=h264,hevc,mpegvideo,mpeg4video,vp8,vp9,av1,vc1,h263,mjpeg,mpegaudio,aac,aac_latm,ac3,dca,mlp,flac,opus,vorbis,cook,rv30,rv40
  --enable-decoder=h264,hevc,mpeg2video,mpeg1video,mpeg4,msmpeg4v1,msmpeg4v2,msmpeg4v3,h263,h263p,wmv1,wmv2,wmv3,vc1,mjpeg,theora,vp8,vp9,libdav1d,rv10,rv20,rv30,rv40,mp2,mp2float,mp3,aac,aac_latm,ac3,eac3,dca,truehd,flac,alac,opus,vorbis,wmav1,wmav2,wmapro,wmalossless,wavpack,ape,tta,amrnb,amrwb,speex,cook,sipr,ra_144,ra_288,atrac3,adpcm_ima_wav,adpcm_ima_qt,adpcm_ms
  --enable-decoder=pcm_bluray,pcm_dvd,pcm_s16le,pcm_s16be,pcm_s24le,pcm_s24be,pcm_s32le,pcm_s32be,pcm_f32le,pcm_f32be,pcm_f64le,pcm_f64be,pcm_u8,pcm_s8,pcm_alaw,pcm_mulaw
  --enable-decoder=subrip,srt,webvtt,movtext,ass,ssa,text
  --enable-videotoolbox --enable-hwaccel=h264_videotoolbox,hevc_videotoolbox
  --enable-avfilter --enable-filter=yadif,bwdif,scale,format,aresample
  --enable-swresample --enable-swscale
  --enable-bsf=h264_mp4toannexb,hevc_mp4toannexb,aac_adtstoasc)

build() { # platform arch min-flag
  local PLAT=$1 ARCH=$2 MINF=$3
  local SDK; SDK=$(xcrun --sdk "$PLAT" --show-sdk-path)
  local PREFIX="$OUT/${PLAT}-${ARCH}"
  [ -d "$PREFIX/lib" ] && [ -z "${FF_REBUILD:-}" ] && [ "$(cat "$PREFIX/.channo-build" 2>/dev/null || true)" = "$BUILD_DIGEST" ] && { echo "Have ${PLAT}-${ARCH} (FF_REBUILD=1 to redo)"; return; }
  echo "Building ${PLAT}-${ARCH}…"
  mkdir -p "$OUT/obj-${PLAT}-${ARCH}" && cd "$OUT/obj-${PLAT}-${ARCH}"
  # External static libraries (dav1d) are not tracked by FFmpeg's link dependencies.
  # A changed fingerprint must discard old objects, even if configure output is identical.
  [ ! -f ffbuild/config.mak ] || make distclean
  # Apple's SDK supplies libxml2. Describe the target SDK to pkg-config so
  # cross builds never accidentally link the host's XML library.
  local SDK_PC="$OUT/sdk-pkgconfig-${PLAT}-${ARCH}"
  local XML_VERSION
  XML_VERSION=$(sed -n 's/^#define LIBXML_DOTTED_VERSION "\(.*\)"/\1/p' "$SDK/usr/include/libxml2/libxml/xmlversion.h")
  [ -n "$XML_VERSION" ] || { echo "error: SDK libxml2 header missing" >&2; exit 1; }
  mkdir -p "$SDK_PC"
  cat > "$SDK_PC/libxml-2.0.pc" <<PCFILE
prefix=$SDK/usr
includedir=\${prefix}/include
Name: libXML
Description: Target Apple SDK libxml2
Version: $XML_VERSION
Libs: -lxml2
Cflags: -I\${includedir}/libxml2
PCFILE
  PKG_CONFIG_LIBDIR="$OUT/dav1d-${PLAT}-${ARCH}/lib/pkgconfig:$SDK_PC" PKG_CONFIG_PATH="" \
  "$SRC/configure" "${COMMON[@]}" --pkg-config="$(command -v pkg-config)" --prefix="$PREFIX" \
    --enable-cross-compile --target-os=darwin --arch="$ARCH" \
    --cc="xcrun -sdk $PLAT clang" --sysroot="$SDK" \
    --extra-cflags="-arch $ARCH $MINF" --extra-ldflags="-arch $ARCH $MINF" \
    --install-name-dir='@rpath'
  make -j"$(sysctl -n hw.ncpu)" && make install
  printf '%s\n' "$BUILD_DIGEST" > "$PREFIX/.channo-build"
}
# #27: tvOS slices for ChannoTV (VideoToolbox + SecureTransport available on tvOS).
for P in ${FF_PLATFORMS:-iphoneos iphonesimulator appletvos appletvsimulator}; do
  case $P in
    iphoneos) build iphoneos arm64 "-mios-version-min=17.0" ;;
    iphonesimulator) build iphonesimulator arm64 "-mios-simulator-version-min=17.0" ;;
    appletvos) build appletvos arm64 "-mappletvos-version-min=18.0" ;;
    appletvsimulator) build appletvsimulator arm64 "-mappletvsimulator-version-min=18.0" ;;
  esac
done
echo "DONE: $OUT"
