#!/bin/bash
# Retain Channo's LGPL patches with the corresponding upstream FFmpeg sources.
set -euo pipefail
PATCH_ROOT="$(cd "$(dirname "$0")" && pwd)"
SOURCE_DIR="${1:?FFmpeg source directory required}"
for patch_file in "$PATCH_ROOT"/patches/*.patch; do
  if patch --batch --forward --dry-run -p1 -d "$SOURCE_DIR" < "$patch_file" >/dev/null 2>&1; then
    patch --batch --forward -p1 -d "$SOURCE_DIR" < "$patch_file"
  elif patch --batch --reverse --dry-run -p1 -d "$SOURCE_DIR" < "$patch_file" >/dev/null 2>&1; then
    echo "Already applied: $(basename "$patch_file")"
  else
    echo "error: source does not match $(basename "$patch_file")" >&2
    exit 1
  fi
done
